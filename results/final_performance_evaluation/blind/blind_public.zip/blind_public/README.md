# Blinded A/B ballot

There are 96 trials: 16 fixed sample seeds for each of 3 training seeds × 2 NFE settings. For every trial, enter a stable anonymous rater ID and exactly one of `A`, `B`, or `TIE` in `ballot.csv`. Judge overall visual quality; use `TIE` when neither image is meaningfully preferable. Do not inspect filenames or request the private unblinding key before all ballots are locked.
